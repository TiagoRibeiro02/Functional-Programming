(* Fibonacci (com e sem memoização) *)

let rec fib n =
  if n <= 2 then 1
  else fib (n-1) + fib (n-2)
  
let fib_memo n =
  let hash_tbl = Hashtbl.create 50 in
  let rec fib_memo_aux n =
    if Hashtbl.mem hash_tbl n then Hashtbl.find hash_tbl n
    else
      let fib_n =
        if n <= 2 then 1
        else fib_memo_aux (n-1) + fib_memo_aux (n-2) 
      in
      let () = Hashtbl.add hash_tbl n fib_n in
      fib_n
  in
  fib_memo_aux n
         
let a = fib 30
let b = fib_memo 30

(* Fibonacci com contagem (com e sem memoização) *)

let rec fib_count n acc = 
  if n <= 2 then (1, acc+1) 
  else 
    let f_n1, acc_n1 = fib_count (n-1) (acc) in
    let f_n2, acc_n2 = fib_count (n-2) (acc) in
    (f_n1 + f_n2, acc_n1 + acc_n2 + 1)
  
let fib_memo_count n =
  let hash_tbl = Hashtbl.create 50 in
  let rec fib_memo_aux n acc =
    if Hashtbl.mem hash_tbl n then (Hashtbl.find hash_tbl n, acc+1)
    else
      let fib_n, acc_n =
        if n <= 2 then (1, acc+1)
        else     
          let f_n1, acc_n1 = fib_memo_aux (n-1) (acc) in
          let f_n2, acc_n2 = fib_memo_aux (n-2) (acc) in
          (f_n1 + f_n2, acc_n1 + acc_n2 + 1) 
      in
      let () = Hashtbl.add hash_tbl n fib_n in
      (fib_n, acc_n) 
  in
  fib_memo_aux n 0
         
let n = 30
let a, tot1 = fib_count n 0
let b, tot2 = fib_memo_count n

(* Motzkin Number (Problema A, 2022/2023) *)

let motzkin n =
  let hash_tbl = Hashtbl.create 50 in
  let rec motzkin_aux n =
    if Hashtbl.mem hash_tbl n then Hashtbl.find hash_tbl n
    else
      let motzkin_n =
        if n < 2 then 1
        else 
          ((2*n+1) * motzkin_aux (n-1) + (3*n-3) * motzkin_aux (n-2))/(n+2) 
      in
      let () = Hashtbl.add hash_tbl n motzkin_n in
      motzkin_n
  in
  motzkin_aux n

let n = 7
let a = motzkin n

(* Schröder number (Problema A, 2021/2022) *)

let sn n =
  let hash_tbl = Hashtbl.create 50 in
  let rec sn_aux n =
    if Hashtbl.mem hash_tbl n then Hashtbl.find hash_tbl n
    else
      let sn_n =
        if n = 0 then 1
        else if n = 1 then 2
        else 
          ((6*n-3) * sn_aux (n-1) - (n-2) * sn_aux (n-2))/(n+1) 
      in
      let () = Hashtbl.add hash_tbl n sn_n in
      sn_n
  in
  sn_aux n

let n = 7
let a = sn n
