(* Funções de Stack: pop, push, is_empty *)

let pop stack = 
  match stack with
  | [] -> failwith "Stack Empty"
  | el::rx -> (el,rx)

let push n stack =  n::stack 
               
let is_empty stack = stack = []     

let lst = [2;3;4]
let el, new_stack = pop lst 
let new_stack = push 1 new_stack 
let new_stack = push 5 new_stack
let el, new_stack = pop new_stack 
let _ = is_empty new_stack

(* Invert list (with stack) *) 

let invert_list lst =
  let rec invert_list lst stack =
    if is_empty lst then stack
    else 
      let pop_el, tl_lst = pop lst in
      let new_stack = push pop_el stack in
      invert_list tl_lst new_stack
  in invert_list lst []
  

let lst = [2;3;4]
let inv_lst = invert_list lst

(* Remover pares de elementos adjacentes em lista *) 

let remove_adj_pair lst = 
  let rec remove_adj_pair_aux lst stack =
    match lst with
    | [] -> List.rev stack
    | el::rx ->
        if is_empty stack then remove_adj_pair_aux rx (push el stack) 
        else 
          let pop_el, tl_stack = pop stack in
          if pop_el = el then remove_adj_pair_aux rx tl_stack
          else remove_adj_pair_aux rx (push el stack) 
  in remove_adj_pair_aux lst [] 
  
let lst = [1;2;2;1;4;6]
let inv_lst = remove_adj_pair lst
