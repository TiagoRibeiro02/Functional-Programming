(* Memoização - Tribonacci *)

let rec trib n = 
  if n <= 2 then 1
  else (trib (n-1)) + (trib (n-2)) + (trib (n-3))
  
let trib_memo n =
  let hash_tbl = Hashtbl.create 50 in
  let rec trib_memo_aux n =
    if Hashtbl.mem hash_tbl n then Hashtbl.find hash_tbl n
    else
      let fib_n =
        if n <= 2 then 1
        else (trib_memo_aux (n-1)) + (trib_memo_aux (n-2)) + (trib_memo_aux (n-3))
      in
      let () = Hashtbl.add hash_tbl n fib_n in
      fib_n
  in
  trib_memo_aux n
    
let a = trib 30
let b = trib_memo 30

(* Stacks *)

let pop stack = 
  match stack with
  | [] -> failwith "Stack Empty"
  | el::rx -> (el,rx) 
let push n stack =  n::stack 
let is_empty stack = stack = []   

(* Ex. 2 *)
                       
let processa lst1 lst2 =
  let rec processa_aux lst stack =
    match lst with
    | [] -> stack
    | el::rx ->
        if el = '#' then 
          if is_empty stack then processa_aux rx stack
          else 
            let _, tl_stack = pop stack in
            processa_aux rx tl_stack
        else processa_aux rx (push el stack)
  in
  processa_aux lst1 [] = processa_aux lst2 []

let a = processa ['a';'b';'#';'c'] ['a';'d';'#';'c']
let a = processa ['a';'b';'#';'#'] ['c';'#';'d';'#']
let a = processa ['a';'#';'c'] ['b']


(* Ex. 2 Extra *)

let ordena lst =
  let rec create_stack lst stack =
    match lst with
    | [] -> stack
    | el::rx -> create_stack rx (push el stack)
  in
  let rec ordena_aux lst i stack stack_acc =
    match lst with
    | [] -> List.rev stack_acc
    | el::rx ->
        let pop_el, tl_stack = pop stack in
        if pop_el = el then List.rev (push el stack_acc) else
        if i mod 2 = 1 then
          ordena_aux lst (i+1) tl_stack (push pop_el stack_acc)
        else ordena_aux rx (i+1) stack (push el stack_acc)
  in
  let stack = create_stack lst [] in
  ordena_aux lst 0 stack []
    
let a = ordena [1;2;3;4]
let a = ordena [1;2;3;4;5]
